def Hello():
    print("Hello Geeks! Welcome to ShapeAI")

Hello()