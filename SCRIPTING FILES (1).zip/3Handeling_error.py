try:
  num = int(input("Enter a integer: "))
  print(f"Hey you entered {num}, is it your lucky number XD")
except:
  print("Not a valid number")

# num = int(input("Enter a integer: "))
# print(f"Hey you entered {num}, is it your lucky number XD")