name = input("Entetr the name: ")
print(f"Hello {name}!!")